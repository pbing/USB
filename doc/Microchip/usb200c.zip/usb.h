unsigned char GetEP1 (unsigned char buffer[]);
unsigned char PutEP1 (unsigned char bytes, unsigned char buffer[]);
extern void StallUSBEP(char);
extern void UnstallUSBEP(char);
extern void CheckSleep();
extern void InitUSB();
extern void RemoteWakeup();
extern void SoftDetachUSB();
extern void ServiceUSB();
extern void USBReset();
extern void USBActivity();

extern bank2 unsigned char USB_dev_req;
extern bank2 unsigned char USB_Curr_Config; 
extern bank2 unsigned char USB_address_pending;




