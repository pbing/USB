//                            Software License Agreement
//
// The software supplied herewith by Microchip Technology Incorporated (the "Company")
// for its PICmicro� Microcontroller is intended and supplied to you, the Company�s
// customer, for use solely and exclusively on Microchip PICmicro Microcontroller
// products.
//
// The software is owned by the Company and/or its supplier, and is protected under
// applicable copyright laws. All rights are reserved. Any use in violation of the
// foregoing restrictions may subject the user to criminal sanctions under applicable
// laws, as well as to civil liability for the breach of the terms and conditions of
// this license.
//
// THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES, WHETHER EXPRESS,
// IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE
// COMPANY SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
//
// ###############################################################################
// filename:		USB_CH9.C
//
// Implements the chapter 9 enumeration commands for Microchip's
// PIC16C7x5 parts.  
//
// ###############################################################################
//
// Authors:		Reston Condit, Dan Butler
// Company:		Microchip Technology Inc
// 
// Revision:		2.00 (Polling version)
// Date:		06 November 2002
// Compiled using	HI-TECH C V8.00 PL4
//
// ################################################################################
// 
// include files:
#include "pic.h"
#include "usb_defs.h"
// 
// ################################################################################

void TokenDone ();
void USBSleep ();
void USBStall ();
void USBError ();

bank2 unsigned char isidle;
bank2 unsigned char USB_status_device;
bank2 unsigned char USB_Curr_Config; 
bank2 unsigned char USB_address_pending;
bank2 unsigned char USB_dev_req;
bank2 unsigned char USB_Interface [3];
bank2 unsigned char USB_USTAT;
bank2 unsigned char USB_protocol;

static volatile unsigned int USB_Buffer @ 0x1b8;

bank2 unsigned int USB_PID_ERR   = 0;
bank2 unsigned int USB_CRC5_ERR  = 0;
bank2 unsigned int USB_CRC16_ERR = 0;
bank2 unsigned int USB_DFN8_ERR  = 0;
bank2 unsigned int USB_BTO_ERR   = 0;
bank2 unsigned int USB_WRT_ERR   = 0;
bank2 unsigned int USB_OWN_ERR   = 0;
bank2 unsigned int USB_BTS_ERR   = 0;

const char * EP0_start;
const char * EP0_end;
bank2 unsigned char EP0_maxLength;

struct BufferDescriptorEntry 
{
	unsigned char EPStat;
	unsigned char bytes;
	unsigned char address;
	unsigned char filler;
};
struct BufferStruct 
{
	unsigned char bmRequestType;
	unsigned char bRequest;
	unsigned int   wValue;
	unsigned int   wIndex;
	unsigned int   wLength;
};

bank2 struct BufferDescriptorEntry * BDT= (struct BufferDescriptorEntry *)0xa0;
bank2 struct BufferStruct * bank2 Buffer;
bank2 struct BufferStruct  BufferCopy;
bank2 struct BufferDescriptorEntry BDTCopy;

const char ReportDescriptor1 [] =      {0x05, 0x01,	/* usage page */
					0x09, 0x02,	/* usage mouse */
					0xa1, 0x01,	/* collection (application) */
					0x09, 0x01,	/* usage (pointer) */
					0xa1, 0x00,	/* collection (linker) */
					0x05, 0x09,	/* usage page (buttons) */
					0x19, 0x01,	/* usage minimum (1) */
					0x29, 0x03,	/* usage maximum (3) */
					0x15, 0x00,	/* logical minimum (0) */
					0x25, 0x01,	/* logical maximum (0) */
					0x95, 0x03,	/* report count (3 bytes) */
					0x75, 0x01,	/* report size (1 bit) */
					0x81, 0x02, 	/* input (3 bits) */
					0x95, 0x01,	/* report count (1 byte) */
					0x75, 0x05,	/* Report size (5 bits) */
					0x81, 0x01, 	/* input (constant 5 bit padding) */
					0x05, 0x01,	/* usage page (generic desktop) */
					0x09, 0x30,	/* usage X */
					0x09, 0x31,	/* usage Y */
					0x15, 0x81,	/* logical minimum -127 */
					0x25, 0x7F,	/* logical maximum 127 */
					0x75, 0x08,	/* report size (8) */
					0x95, 0x03,	/* report count 2 */
					0x81, 0x06,	/* input (2 position butes X & Y) */
					0xc0, 0xc0};	/* end collection */

const unsigned int ReportDescrSize = sizeof(ReportDescriptor1);

const char DeviceDescriptor [] = {0x12, DEVICE, 0x10, 0x01, 0x00, 0x00, 0x00, 0x08, 0xD8, 
				  0x04 ,0x01, 0x00, 0x00, 0x02, 0x01, 0x02, 0x00, 0x01};
const char ConfigDescriptor [] = {0x09, CONFIGURATION, 0x22, 0x00, 0x01, 0x01, 0x00, 0xA0, 0x32, 
/* Interface Descriptor  */       0x09, INTERFACE, 0x00, 0x00, 0x01, 0x03, 0x01, 0x02, 0x00,
/* HID descriptor        */       0x09, 0x21, 0x00, 0x01, 0x00, 0x01, 0x22, sizeof(ReportDescriptor1), sizeof(ReportDescriptor1)>>8,
/* Endpoint 1 descriptor */       0x07, ENDPOINT, 0x81, 0x03, 0x04, 0x00, 0x0A};
const char HIDDescriptor [] =    {0x09, 0x21, 0x00, 0x01, 0x00, 0x01, 0x22, sizeof(ReportDescriptor1), sizeof(ReportDescriptor1)>>8};
const char String0 [] = { 4, STRING, 9, 4};
const char String1 [] = {54, STRING, 'M', 0, 'i', 0, 'c', 0, 'r', 0, 'o', 0, 'c', 0, 'h', 0, 'i', 0, 'p', 0, ' ', 0,
				     'T', 0, 'e', 0, 'c', 0, 'h', 0, 'n', 0, 'o', 0, 'l', 0, 'o', 0, 'g', 0, 'y', 0, 
				     ',', 0, ' ', 0, 'I', 0, 'n', 0, 'c', 0, '.', 0};
const char String2 [] = {92, STRING, 'P', 0, 'i', 0, 'c', 0, '1', 0, '6', 0, 'C', 0, '7', 0, '4', 0, '5', 0, '/', 0, 
				     '7', 0, '6', 0, '5', 0, ' ', 0, 'U', 0, 'S', 0, 'B', 0, ' ', 0, 'S', 0, 'u', 0,
				     'p', 0, 'p', 0, 'o', 0, 'r', 0, 't', 0, ' ', 0, 'F', 0, 'i', 0, 'r', 0, 'm', 0,
				     'w', 0, 'a', 0, 'r', 0, 'e', 0, ',', 0, ' ', 0, 'V', 0, 'e', 0, 'r', 0, '.', 0,
				     ' ', 0, '2', 0, '.', 0, '0', 0, '0', 0};

/* ****** */
/* PutEP1 **************************************************************** */
/* Tests the EP1 IN OWNS bit.  If there is a buffer available to us, your  */
/* buffer is copied and turned over to the SIE for transmission on the     */
/* next IN transfer and returns TRUE (1).  If the buffer is not available, */
/* FALSE is returned (0).                                                  */
/* *********************************************************************** */
unsigned char PutEP1 (unsigned char bytes, unsigned char *buffer)
{
	bank2 unsigned char * tobuffer;
	unsigned char i;

	if ((BD1IST & 0x80) == 0)  /* do we own the buffer? */
	{
		BD1IBC = bytes;
		tobuffer = (unsigned char *)BD1IAL;
		for (i = 0; i < bytes; i++)
			tobuffer [i] = buffer[i];
		BD1IST &= 0x40; /* save only the Data 1/0 bit */
		BD1IST ^= 0x40; /* toggle Data 0/1 bit */
		BD1IST |= 0x88;	/* Turn the buffer back over to the SIE */
		return TRUE;
	}
	else
		return FALSE;			/* Buffer not available, return false */
}


/* ****** */
/* GetEP1 **************************************************************** */
/* Tests the EP1 OUT OWNS bit.  If there is a buffer available to us (data */
/* has been received, it copies the buffer to your buffer and returns the  */
/* number of bytes received.  If no buffer is available, it returns 0      */
/* *********************************************************************** */
unsigned char GetEP1 (unsigned char *buffer)
{
	bank2 unsigned char *  FromBuffer;
	unsigned char i;

	if ((BD1OST & 0x80) == 0)  /* do we own the buffer? */
	{
		FromBuffer = (unsigned char * )BD1OAL;
		for (i = 0; i < BD1OBC; i++)
			buffer [i] = FromBuffer[i];
		BD1OST &= 0x40; /* save only the Data 1/0 bit */
		BD1OST ^= 0x40; /* toggle Data 0/1 bit */
		BD1OST |= 0x88;	/* Turn the buffer back over to the SIE */
		return BD1OBC;
	}
	else
		return FALSE;			/* Buffer not available, return false */
}


/* ******************* */
/* CopyDescriptorToEP0 ************************************************** */
/* copies the next chunk of buffer descriptor over to the EP0 In buffer.  */
/* Inputs:                                                                */
/*    EP0_start - points to first byte of configuration table to transfer */
/*    EP0_end - total number of bytes to transfer                         */
/*    EP0_maxLength - maximum number of bytes that can be sent during     */
/*    a single transfer                                                   */
/*                                                                        */
/* toggles the data0/1 bit before setting the UOWN bit over to SIE.       */
/* ********************************************************************** */
void CopyDescriptorToEP0 ()
{
	bank2 unsigned char *  USBbuffer;  /* pointer to the USB Buffers */
	unsigned char bufindex;

	USBbuffer = (unsigned char * ) BD0IAL + 0x100;
	bufindex  = 0;

	while ((bufindex < EP0_maxLength) && (EP0_start < EP0_end))
	{
		USBbuffer [bufindex] = *EP0_start;
		++ EP0_start;
		++ bufindex;
	}
	if (bufindex < EP0_maxLength)	/* are we sending a short packet? */
		USB_dev_req = 0;	/* Yes, clear the device reqest */
	BD0IBC  = bufindex;
	BD0IST &= 0x40;		/* save only the Data0/1 bit */
	BD0IST ^= 0x40;		/* toggle data 0/1 bit */
	BD0IST |= 0x88;		/* set OWN and DTS bits */
}



/* ******** */
/* Init USB ********************************************************* */
/* Initializes the USB peripheral, sets up the interrupts             */
/* ****************************************************************** */
void InitUSB ()
{
	USWSTAT           = 0;		// default to powered state
	UIE               = 0x01;	// enable the Reset interrupt only
	UIR               = 0;		// clear all USB interrupt flags
	UCTRL             = 0x08;	// Device attached
	USB_Curr_Config   = 0;
	USB_status_device = 1;
	USB_Interface [0] = 0;
	USB_Interface [1] = 0;
	USB_Interface [2] = 0;
	USB_dev_req       = NULL;
	USB_PID_ERR       = 0;
	USB_CRC5_ERR      = 0;
	USB_CRC16_ERR     = 0;
	USB_DFN8_ERR      = 0;
	USB_BTO_ERR       = 0;
	USB_WRT_ERR       = 0;
	USB_OWN_ERR       = 0;
	USB_BTS_ERR       = 0;
	USBIF             = 0;
	USBIE             = 1;
	INTCON            = INTCON | 0xC0;	// Enable GIE & PEIE
#ifdef SHOW_ENUM_STATUS
	RB0               = 1;
#endif
}

/* ****************************************************************** */
/* DeInit USB                                                         */
/* Shuts down the USB peripheral, clears the interrupt enable.        */
/* ****************************************************************** */
void DeInitUSB ()
{
	DEV_ATT = 0;
	SUSPND  = 1;
	USWSTAT = 0;
	USBIE   = 0;
#ifdef SHOW_ENUM_STATUS
	PORTB 	= 0x01;	
#endif
}

/* *************** */
/* Stall Endpoint. ***************************************************** */
/* Sets the stall bit in the Endpoint Control Register.  For the control */
/* Endpoint, this implements a Protocol stall and is used when the request */
/* is invalid for the current device state.  For non-control Endpoints,  */
/* this is a Functional Stall, meaning that the device needs outside     */
/* intervention and trying again later won't help until it's been serviced. */
/* enter with endpoint # to stall in Wreg.                               */
/* ********************************************************************* */
void StallUSBEP (unsigned char EndPoint)
{
	*(&UEP0 + EndPoint) |= 1;
}

/* ***************** */
/* Unstall Endpoint. ***************************************************** */
/* Sets the stall bit in the Endpoint Control Register.  For the control   */
/* Endpoint, this implements a Protocol stall and is used when the request */
/* is invalid for the current device state.  For non-control Endpoints,    */
/* this is a Functional Stall, meaning that the device needs outside       */
/* intervention and trying again later won't help until it's been serviced. */
/* enter with endpoint # to stall in Wreg.                                 */
/* *********************************************************************** */
UnstallUSBEP (unsigned char EndPoint)
{
	*(&UEP0 + EndPoint) &= 0xFE;
}


/* ********************************************************************* */
/* USB Soft Detach                                                       */
/* Clears the DEV_ATT bit, electrically disconnecting the device to the  */
/* bus.  This removes the device from the bus, then reconnects so it can */
/* be re-enumerated by the host.  This is envisioned as a last ditch     */
/* effort by the software.                                               */
/* ********************************************************************* */
void SoftDetachUSB ()
{
	unsigned int i;

	DEV_ATT = 0;	// clear the attach bit
	for (i = 0; i < 65000; i++);  // delay 50mS
	InitUSB ();
}

/* ******************************************************************** */
/* Remote Wakeup                                                        */
/* Checks USB_status_device to see if the host enabled Remote Wakeup.   */
/* If so, perform Remote wakeup and disable remote wakeup feature.      */
/* It is called by PortBChange.                                         */
/* ******************************************************************** */

void RemoteWakeup ()
{
	unsigned int i;
	if (USB_status_device&0x02) {
		SUSPND = 0;
		UIDLE = 0;
		isidle = 0;
		ACTIVITY_E = 0;
		ACTIVITY = 0;
		UCTRL |= 0x04;
		for (i = 0; i < 10000; i++);   // delay 10ms
		UCTRL &= 0xFB;
	}
}

/* ****************************************************************** */
/* USB Reset interrupt triggered (SE0)                                */
/* initialize the Buffer Descriptor Table,                            */
/* Transition to the DEFAULT state,                                   */
/* Set address to 0                                                   */
/* enable the USB                                                     */
/* ****************************************************************** */
void USBReset ()
{
	USB_Curr_Config = 0;
	isidle   = 0;

	TOK_DONE = 0;	// clear 4 times to clear out the USTAT FIFO
	TOK_DONE = 0;
	TOK_DONE = 0;
	TOK_DONE = 0;

	BD0OBC   = 8;
	BD0OST   = 0x88;	// EP0 Out buffer
	BD0OAL   = 0xB8;

	BD0IST   = 0x08;
	BD0IAL   = 0xC0;

	UADDR    = 0;
	UIR      = 0;
	UIE	 = 0x05; 	// enable reset and activity interrupt

	UEP0     = ENDPT_CONTROL;
	USWSTAT  = DEFAULT_STATE;
	USB_status_device = 1;
#ifdef SHOW_ENUM_STATUS
	RB1 = 1;		// set bit one to indicate Reset status
#endif
}

/* ********************************************************************* */
/* Branch off and service the USB interrupt flags			 */
/* ********************************************************************* */
void ServiceUSB ()
{
	if (TOK_DONE)		
		TokenDone();	
	if (STALL)		
		USBStall ();	 
	if (UERR)		
		USBError ();	
	if (UIDLE)		
		USBSleep ();
}

/* ********************************************************************* */
/* This is activated by the STALL bit in the UIR register.  It really    */
/* just tells us that the SIE sent a STALL handshake.  So far, Don't     */
/* see that any action is required.  Clear the bit and move on.          */
/* ********************************************************************* */
void USBStall ()
{
	STALL = 0;
}

/* ********************************************************************* */
/* Enable Wakeup on interupt and Activity interrupt then put the         */
/* device to sleep to save power.  Activity on the D+/D- lines will      */
/* set the ACTIVITY interrupt, waking up the part.                       */
/* ********************************************************************* */
void USBSleep ()
{
	ACTIVITY_E = 1;
	UIDLE      = 0;
	SUSPND	   = 1;
	isidle     = 1;
}

/* ********************************************************************* */
/* Service the Activity Interrupt.  This is only enabled when the        */
/* device is put to sleep as a result of inactivity on the bus.  This    */
/* code wakes up the part, disables the activity interrupt and reenables */
/* the idle interrupt.                                                   */
/* ********************************************************************* */
void USBActivity ()
{
	ACTIVITY   = 0;
	ACTIVITY_E = 0;
	SUSPND     = 0;
	isidle     = 0;
}

/* ****************************************************************** */
/* The SIE detected an error.  This code increments the appropriate   */
/* error counter and clears the flag.                                 */
/* ****************************************************************** */
void USBError ()
{
	if (PID_ERR && PID_ERR_E)
		++ USB_PID_ERR;
	if (CRC5 && CRC5_E)
		++ USB_CRC5_ERR;
	if (CRC16 && CRC16_E)
		++ USB_CRC16_ERR;
	if (DFN8 && DFN8_E)
		++ USB_DFN8_ERR;
	if (BTO_ERR && BTO_ERR_E)
		++ USB_BTO_ERR;
	if (WRT_ERR && WRT_ERR_E)
		++ USB_PID_ERR;
	if (OWN_ERR && OWN_ERR_E)
		++ USB_OWN_ERR;
	if (BTS_ERR && BTS_ERR_E)
		++ USB_BTS_ERR;
	UEIR = 0;
	UERR = 0;
}


/* ******************************************************************* */
/* Process token done interrupt...  Most of the work gets done through */
/* this interrupt.  Token Done is signaled in response to an In, Out,  */
/* or Setup transaction.                                               */
/* ******************************************************************* */
void TokenDone ()
{
	bank3 unsigned char  *OutBuffer;
	bank3 unsigned char *UEPArray;
	unsigned char  DescriptorType;
	unsigned char  Endpoint;
	unsigned char  Interface;
	unsigned char  DescriptorID;
	unsigned char  StringID;

	BDTCopy.EPStat  = BDT[USTAT/4].EPStat;
	BDTCopy.address = BDT[USTAT/4].address;
	BDTCopy.bytes   = BDT[USTAT/4].bytes;
	USB_USTAT       = USTAT;
	TOK_DONE        = 0;

#ifdef SHOW_ENUM_STATUS
	if (USB_USTAT == 0x00)  PORTB ^= 0x20;
	if (USB_USTAT == 0x08)  PORTB ^= 0x40;
	if (USB_USTAT == 0x18)  PORTB ^= 0x80;
#endif
	if ((BDTCopy.EPStat & 0x3C) == TOKEN_IN)
	{
		if (USB_USTAT == 0x04)
		{ /* Process EP0 In's */
			if (USB_dev_req == GET_DESCRIPTOR)
			{
				CopyDescriptorToEP0 ();
			}
		}
		else if (USB_USTAT == 0x0C)
		{ /* process EP1 In's */
		}
		else
		{ /* process EP2 In's */
		}
	}
	else if ((BDTCopy.EPStat & 0x3C) == TOKEN_OUT)
	{
		if (USB_USTAT == 0x00)
		{ /* Process EP0 Out's */
//			if (USB_dev_req == HID_SET_REPORT)
//			{
// Call your own function that will implement Set_Report here. Be sure to enable HID_SET_REPORT
//   below.  (Search for "HID_SET_REPORT".)
//				STALL_EP0;
//			}
//			BD0OBC = 0x08;		// Reset buffer and move on.
//			BD0OST = 0x88;
//			if (BufferCopy.wLength > 8)
//				(BufferCopy.wLength -= 8;
//			else
//				Send_0Len_pkt;
		}
		else if (USB_USTAT == 0x08)
		{ /* process EP1 Out's */
		}
		else
		{ /* process EP2 Out's */
		}
	}
	else if ((BDTCopy.EPStat & 0x3C) == TOKEN_SETUP)
	{
		
		Buffer = (struct BufferStruct * bank2) BD0OAL;
		BufferCopy.bmRequestType = Buffer->bmRequestType;
		BufferCopy.bRequest      = Buffer->bRequest;
		BufferCopy.wValue        = Buffer->wValue;
		BufferCopy.wIndex        = Buffer->wIndex;
		BufferCopy.wLength       = Buffer->wLength;

		PID0_0I = 0;		// Clear REQUEST ERROR
		BD0OBC      = 0x08;
		if (BufferCopy.bmRequestType == 0x21)
			BD0OST	= 0xC8;
		else
			BD0OST  = 0x88;	/* Turn the buffer around, make it available for the SIE */
		BD0IST      = 0x08;
		PKT_DIS     = 0;
		USB_dev_req = 0;

		switch (BufferCopy.bmRequestType)
		{
		case HOSTTODEVICE:
			switch (BufferCopy.bRequest)
			{
			case CLEAR_FEATURE:	/* Remote wakeup is only valid device feature */
				if (BufferCopy.wValue == 1)
				{
					USB_status_device &= 0xFD;
					Send_0Len_pkt;
				}
				else
					STALL_EP0;
				break;

			case SET_FEATURE:				/* Set Device Feature.  Only valid device */
				if ((BufferCopy.wValue & 0xff) == 1)
				{
					USB_status_device |= 0x02;	/* feature is remote wakeup */
					Send_0Len_pkt;
				}
				else
					STALL_EP0;
				break;

			case SET_ADDRESS:
				USB_address_pending = BufferCopy.wValue;
				if (USB_address_pending < 0x80)
				{
					Send_0Len_pkt;
					USB_dev_req = SET_ADDRESS;
					UIE = 0x09;
				}
				else
					STALL_EP0;
				break;

			case SET_CONFIGURATION:
				if (BufferCopy.wValue <= NUM_CONFIGURATIONS)
					USB_Curr_Config = BufferCopy.wValue;

				if (BufferCopy.wValue == 0)
					USWSTAT = ADDRESS_STATE;
				else
				{
					USWSTAT = CONFIG_STATE;
#ifdef SHOW_ENUM_STATUS
					RB3 = 1;		// set bit 3 to show configured
#endif
				}
				Send_0Len_pkt;
				BD1OST = 0x88;
				BD1OAL = (unsigned char)Buffer + 0x10;
				BD1OBC = 8;

				BD1IST = 0x48;
				BD1IAL = (unsigned char)Buffer + 0x18;
				BD1IBC = 8;

				BD2OST = 0x88;
				BD2OAL = (unsigned char)Buffer + 0x20;
				BD2OBC = 8;

				BD2IST = 0x48;
				BD2IAL = (unsigned char)Buffer + 0x20;
				BD2IBC = 8;

				UEP1 = ENDPT_NON_CONTROL;
				UEP2 = ENDPT_NON_CONTROL;

				break;

			default:
				STALL_EP0;
				break;
			}
			break;

		case HOSTTOINTERFACE:
			switch (BufferCopy.bRequest)
			{
			case SET_INTERFACE:
				if (USWSTAT == CONFIG_STATE)
				{
					Interface = BufferCopy.wIndex;
					USB_Interface [Interface] = BufferCopy.wValue;
					Send_0Len_pkt;
				}
				else
					STALL_EP0;
				break;

			case CLEAR_FEATURE:
			case SET_FEATURE:	/* Set Interface feature - Not Valid */
			default:
				STALL_EP0;
				break;
			}
			break;

		case HOSTTOENDPOINT:
			switch (BufferCopy.bRequest)
			{
			case CLEAR_FEATURE:
				UEPArray = (unsigned char *) &UEP0;
				Endpoint = BufferCopy.wIndex & 0x0F;
				if (BufferCopy.wValue == 0)  /* Only valid feature is 0 (Remote Wakeup) */
				{
					if (((USWSTAT & 0x03) == ADDRESS_STATE) && (Endpoint == 0))
					{
						UEPArray [Endpoint] &= 0xFE;
						Send_0Len_pkt;
					}
					else if (((USWSTAT & 0x03) == CONFIG_STATE) && (Endpoint < 3))
					{
						UEPArray [Endpoint] &= 0xFE;
						Send_0Len_pkt;
					}
					else
						STALL_EP0;
				}
				else
					STALL_EP0;
				break;

			case SET_FEATURE:
				UEPArray = (unsigned char *) &UEP0;
				Endpoint = BufferCopy.wIndex & 0x0F;
				if (BufferCopy.wValue == 0)  /* Only valid feature is 0 (Remote Wakeup) */
				{
					if (((USWSTAT & 0x03) == ADDRESS_STATE) && (Endpoint == 0))
					{
						UEPArray [Endpoint] |= 1;
						Send_0Len_pkt;
					}
					else if (((USWSTAT & 0x03) == CONFIG_STATE) && (Endpoint < 3))
					{
						UEPArray [Endpoint] |= 1;
						Send_0Len_pkt;
					}
					else
						STALL_EP0;
				}
				else
					STALL_EP0;
				break;

			default:
				STALL_EP0;
				break;
			}
			break;

		case DEVICETOHOST:
			switch (BufferCopy.bRequest)
			{
			case GET_CONFIGURATION:
				OutBuffer = (unsigned char * bank2)BD0IAL;
				OutBuffer [0] = USB_Curr_Config;
				BD0IBC = 1;
				BD0IST = 0xc8;
				break;

			case GET_DESCRIPTOR:
				DescriptorID = (unsigned char) (BufferCopy.wValue >> 8);
				if (DescriptorID == DEVICE)
				{
					USB_dev_req = GET_DESCRIPTOR;
					EP0_start = DeviceDescriptor;
					EP0_end   = DeviceDescriptor + sizeof(DeviceDescriptor);
					if (BufferCopy.wLength < (EP0_end - EP0_start))
						EP0_end = EP0_start + BufferCopy.wLength;
					EP0_maxLength = 8;
					CopyDescriptorToEP0 ();
				}
				else if (DescriptorID == CONFIGURATION)
				{
					USB_dev_req = GET_DESCRIPTOR;
					EP0_start = ConfigDescriptor;
					EP0_end   = ConfigDescriptor + sizeof(ConfigDescriptor);
					if (BufferCopy.wLength < (EP0_end - EP0_start))
						EP0_end = EP0_start + BufferCopy.wLength;
					EP0_maxLength = 8;
					CopyDescriptorToEP0 ();
				}
				else if (DescriptorID == STRING)
				{
					if (BufferCopy.wIndex != 0x409 && BufferCopy.wIndex != 0)  /* make sure language is supported */
						STALL_EP0;				/* only language 0 is valid */
					else
					{
					StringID = (unsigned char) BufferCopy.wValue;
					USB_dev_req = GET_DESCRIPTOR;
					EP0_maxLength = 8;
					switch (StringID)
					{
					case 0:
						EP0_start = String0;
						EP0_end   = String0 + String0[0];
						if (BufferCopy.wLength < (EP0_end - EP0_start))
							EP0_end = EP0_start + BufferCopy.wLength;
						CopyDescriptorToEP0 ();
						break;
					case 1:
						EP0_start = String1;
						EP0_end   = String1 + String1[0];
						if (BufferCopy.wLength < (EP0_end - EP0_start))
							EP0_end = EP0_start + BufferCopy.wLength;
						CopyDescriptorToEP0 ();
						break;
					case 2:
						EP0_start = String2;
						EP0_end   = String2 + String2[0];
						if (BufferCopy.wLength < (EP0_end - EP0_start))
							EP0_end = EP0_start + BufferCopy.wLength;
						CopyDescriptorToEP0 ();
						break;
					default:
						STALL_PID_EP0IN;	/* REQUEST ERROR */
					}
					}
				}
				else 
					STALL_PID_EP0IN;	/* REQUEST ERROR */
				break;

			case GET_STATUS:
				OutBuffer = (unsigned char *)BDT [EP0IN].address;
				OutBuffer[0] = USB_status_device;
				OutBuffer[1] = 0;
				BD0IBC = 2;
				BD0IST = 0xc8;
				break;

			default:
				break;
			}
			break;

		case INTERFACETOHOST:
			switch (BufferCopy.bRequest)
			{
			case GET_INTERFACE:
				Interface = BufferCopy.wIndex;
				if ((USWSTAT == CONFIG_STATE) && (Interface < NUM_INTERFACES))
				{
					OutBuffer = (unsigned char *) BDT [EP0IN].address;
					OutBuffer[0] = USB_Interface [Interface];
					BD0IBC = 1;
					BD0IST = 0xc8;
				}
				else
					STALL_EP0;
				break;

			case GET_STATUS:
				OutBuffer = (unsigned char *) BDT [EP0IN].address;
				OutBuffer[1] = 0;
				BD0IBC = 2;
				Interface = BufferCopy.wIndex;
				if ((USWSTAT == ADDRESS_STATE) && (Interface == 0))
				{
					OutBuffer[0] = USB_Interface [Interface];
					BD0IST = 0xc8;
				}
				else if ((USWSTAT == CONFIG_STATE) && (Interface < NUM_INTERFACES))
				{
					OutBuffer[0] = USB_Interface [Interface];
					BD0IST = 0xc8;
				}
				else
					STALL_EP0;
				break;

			case GET_DESCRIPTOR:
				DescriptorType = BufferCopy.wValue >> 8;
				if (DescriptorType == 0x22)  /* special HID request to return report descriptor */
				{
					USB_dev_req = GET_DESCRIPTOR;
					if (BufferCopy.wIndex == 0);
					{
						EP0_start = ReportDescriptor1;
						EP0_end   = EP0_start + sizeof (ReportDescriptor1);
						EP0_maxLength = 8;
						if (BufferCopy.wLength < sizeof (ReportDescriptor1))
							EP0_end = EP0_start + BufferCopy.wLength;
						CopyDescriptorToEP0 ();
					}
					if (BufferCopy.wIndex == 1);
					{
						/* Repeat above code for another Report Descriptor. */
					}
				}
				else if (DescriptorType == 0x21) /* HID descriptor */
				{
					USB_dev_req = GET_DESCRIPTOR;
					if (BufferCopy.wIndex == 0)
					{
						EP0_start = HIDDescriptor;
						EP0_end   = EP0_start + sizeof (HIDDescriptor);
						EP0_maxLength = 8;
						if (BufferCopy.wLength < sizeof (HIDDescriptor))
							EP0_end = EP0_start + BufferCopy.wLength;
						CopyDescriptorToEP0 ();
					}
					if (BufferCopy.wIndex == 1)
					{
						/* Repeat above code for another HID Descriptor. */
					}
				}
				else
					STALL_EP0;  /* unrecognised request */
				break;

			default:
				break;
			}
			break;

		case ENDPOINTTOHOST:
			if (BufferCopy.bRequest == GET_STATUS)
			{
				UEPArray = (unsigned char *) &UEP0;
				Endpoint = BufferCopy.wIndex & 0x0F;
				OutBuffer = (unsigned char * ) BD0IAL;
				OutBuffer[1] = 0;
				BD0IBC = 2;

				if (Endpoint < 3)
				{
					OutBuffer[0] = UEPArray [Endpoint] & 0x01;
					BD0IST = 0xc8;
				}
				else
					STALL_EP0;
			}
			break;

		default:
			if (BufferCopy.bmRequestType & 0x20) {
				OutBuffer = (unsigned char * ) BD0IAL;
				switch (BufferCopy.bmRequestType)
				{
				case	0x21:	/* Host to Device HID request */
					switch (BufferCopy.bRequest)
					{
					case 	HID_SET_PROTOCOL:	/* Set Protocol */
						USB_protocol = BufferCopy.wValue;
						Send_0Len_pkt;	
						break;
					case 	HID_SET_REPORT:		/* Set HID Report */
					// Add Set_Report Function above for OUT TOKEN and uncomment
					//   following two lines
					//	USB_dev_req = HID_SET_REPORT;
					//	break;
					case 	HID_SET_IDLE:		/* Set Idle */
					default:
						STALL_EP0;
					}
					break;
				case	0xA1:	/* Dev2HostHIDRequest */
					switch (BufferCopy.bRequest)
					{
					case	HID_GET_PROTOCOL:	/* Get Protocol */
						OutBuffer[0] = USB_protocol;
						BD0IBC = 1;
						BD0IST = 0xC8;
						break;
					case 	HID_GET_REPORT:		/* Get HID Report */
			    		// Add Get_Report Function here and uncomment following two lines
			    		//	BD0IST = 0xc8;	// Turn over BDT to SIE
					//	break;
					case 	HID_GET_IDLE:		/* Get Idle */
					default:
						STALL_EP0;
					}
					break;
				case	0x22:	/* Host2DevReportRequest */
				case	0x23:	/* Host2DevPhysicalRequest */
				case	0xA2:	/* Dev2HostReportRequest */
				case	0xA3:	/* Dev2HostPhysicalRequest */
				default:
					STALL_EP0;
				}		
			}
		}
	}
}



