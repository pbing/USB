//                          Software License Agreement
//
// The software supplied herewith by Microchip Technology Incorporated (the "Company")
// for its PICmicro� Microcontroller is intended and supplied to you, the Company�s
// customer, for use solely and exclusively on Microchip PICmicro Microcontroller
// products.
//
// The software is owned by the Company and/or its supplier, and is protected under
// applicable copyright laws. All rights are reserved. Any use in violation of the
// foregoing restrictions may subject the user to criminal sanctions under applicable
// laws, as well as to civil liability for the breach of the terms and conditions of
// this license.
//
// THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES, WHETHER EXPRESS,
// IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE
// COMPANY SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
// CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
//
// ###############################################################################
// filename:		USB_MAIN.C
//			Sample main program
//
// This file implements a basic interrupt service routine and shows how the
// USB interrupt should be serviced, how InitUSB should be called, and how PutUSB
// should be called.  It may be used as a reference, or as a starting point 
// from which to build an application.  
//
// ###############################################################################
//
// Authors:		Reston Condit, Dan Butler
// Company:		Microchip Technology Inc
//
// Revision:		2.00 (Polling version)
// Date:		06 November 2002
// Compiled using:	HI-TECH C 8.00 PL4
// Configuration Bits:	H4 Oscillator, WDT Off, Power up timer off
// 
// Notes about the polling version:
//
//   V2.00 marks a fairly substantial change in architecture from the V1.xx 
//   versions.  While V1.xx handled the USB completely from the ISR, V2.00 shifts 
//   most of the processing to a function called from the main program loop.  There 
//   are several advantages for this.  Firstly, it eliminates the may levels of the 
//   stack that currently must be reserved for the ISR.  Secondly, it minimizes the 
//   length of the ISR which is desirable from a "good software engineering 
//   practices" standpoint.  And finally it gives control over when the USB is 
//   serviced to the software engineer writing the application.  This is 
//   particularly important for timing critical systems where a few hundred 
//   instruction cycles to process the interrupt at the wrong time could potentially 
//   damage the system.   
//
//   This version is intended for use with the PIC16C745/765, revision A2 only (date 
//   code 0231 and later.)  The PCM16XQ1 processor module must be used to emulate
//   this revision of the silicon.  See the PIC16C745/765 rev. A1 and PIC16C745/765 
//   rev. A2 errata for differences in the revisions.  
//
// Revision History:
//   none
//
//################################################################################
//
// include files:
#include <pic.h>
#include "usb.h"
#include "usb_defs.h"
//
//###############################################################################

__CONFIG(WDTDIS & UNPROTECT & PWRTDIS & H4);


// Interrupt service routine. Branch off to different interrupts
interrupt ISR () {
	if (USBIF && USBIE) {
		if (ACTIVITY)
			USBActivity ();
		if (USB_RST && USB_RST_E)		// USB reset must be serviced immediately
			USBReset ();
		if (TOK_DONE && TOK_DONE_E) {
			if (USB_dev_req == SET_ADDRESS)	// Finish Set Address
			{   				 
				USB_dev_req = NULL;
				USB_Curr_Config = 0;
				UADDR = USB_address_pending;
				UIE = 0x01;		// enable just the reset interrupt
#ifdef SHOW_ENUM_STATUS 				// SHOW_ENUM_STATUS defined in usb_defs.h
				RB2 = 1;		// set bit 2 to show addressed
#endif
 				if (USB_address_pending > 0)
					USWSTAT = ADDRESS_STATE;
				else
					USWSTAT = DEFAULT_STATE;
			}
			TOK_DONE = 0; // clear Token Done flag
		}
		USBIF = 0;		// Clear USB interrupt flag
	}
}

void main() {
	static bit Button_RA4 = 0;
	unsigned char i;
	unsigned char vector = 0;
	unsigned char buffer [4];
	const signed char table [] = {-4, -4, -4, 0, 4, 4, 4, 0};

// The table array contains the directional data for simulated mouse movement.  The Y direction  
//   leads the X direction by two in the array (i.e. (-4,4) then (-4,0) then (-4, 4) then (0, 4)   
//   etc.)  X vectors are positive from left to right on the screen.  Y vectors are positive for  
//   top to bottom.  The result of all these vectors is the cursor moving in a continual octogon. 

	TRISB = 0;
	PORTB = 0;
	TRISA = 0x10;			// RA4 is and input
	PORTA = 0;
	for (i = 0; i < 50; i ++);	// Small delay (greater than 16us) in order to 
	InitUSB ();			//   allow SIE to come online before beginning USB
					//   initialization
	buffer [0] = 0;			
	i = 15;
	OPTION = 0x07;			// TMR0 prescaler 1:256
	while (1)
	{
		if (T0IF) {				// Poll all functions every 10.9ms
			T0IF = 0;
			ServiceUSB();			// Service USB functions
			if (i > 14) {			// Increment octogon vectors
				buffer[1] = table[vector & 0x07];	// X vector (limit to length of table array)	
				buffer[2] = table[(vector+2) & 0x07];	// Y vector (leads X by two)
									//   (limit to length of table array)	
				i = 0;
				vector++;
			}
			if (ConfiguredUSB()) {		// Wait until device is configured before using
							//   EP1.  If Endpoints 1 or 2 are used before
							//   the device is configured, errors will occur.
				if (PutEP1(4, buffer))	// Increment i if EP1 IN buffer is accessible
					i++;		//   to the PIC.  If not accessible, try again
							//   next time.
			}
			if (Button_RA4 && RA4)
				Button_RA4 = 0;
			if (!RA4 && !Button_RA4) {	// if RA4 button is pressed on PICDEM USB board
				RemoteWakeup();		//   perform remote wakeup
				Button_RA4 = 1;
			}
		}
	}
}
